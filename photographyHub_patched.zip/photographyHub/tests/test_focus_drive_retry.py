"""Regression test for _drive_to_offset giving up too early on a focus-step failure.

Bug: _drive_focus() only advances self._focus_offset when camera.focus_step(...)
succeeds. _drive_to_offset() saw self._focus_offset unchanged after one failed
step and broke immediately, using none of its 400-iteration retry budget. USB
focus-step commands over gPhoto2 are a known source of occasional transient
failures, so a single hiccup mid-stack could end a drive-to-target attempt
early, short of the plan, with no retry.

Fix: _drive_to_offset now tolerates a bounded number of consecutive no-op
attempts (transient failures) before giving up, instead of bailing on the
first one. A camera that fails every single call (a genuine, persistent
fault / hard limit) must still cause it to give up promptly rather than
spin for its full 400-iteration guard.
"""
from __future__ import annotations

from types import SimpleNamespace

from desktop_ui.camera_worker import CameraWorker


class _TransientFailureCamera:
    """Fails focus_step every 3rd call, otherwise succeeds -- like an
    occasional USB hiccup that clears up on its own."""

    def __init__(self) -> None:
        self.calls = 0

    def is_connected(self) -> bool:
        return True

    def focus_step(self, direction: str, size: int = 1):
        self.calls += 1
        if self.calls % 3 == 0:
            return SimpleNamespace(success=False, stderr="transient USB error")
        return SimpleNamespace(success=True)

    def capture_preview(self):
        return SimpleNamespace(success=True, preview_data=b"P")


class _AlwaysFailingCamera:
    """Every focus_step call fails -- a genuine, persistent fault."""

    def __init__(self) -> None:
        self.calls = 0

    def is_connected(self) -> bool:
        return True

    def focus_step(self, direction: str, size: int = 1):
        self.calls += 1
        return SimpleNamespace(success=False, stderr="hard limit reached")

    def capture_preview(self):
        return SimpleNamespace(success=True, preview_data=b"P")


def _make_worker(camera) -> CameraWorker:
    worker = CameraWorker()
    worker.camera = camera
    return worker


def test_drive_to_offset_survives_a_transient_focus_step_failure() -> None:
    camera = _TransientFailureCamera()
    worker = _make_worker(camera)

    result = worker._drive_to_offset(10)

    assert result == 10, (
        "A single transient focus_step failure should not stop the drive short "
        f"of the target (landed at {result} instead of 10)"
    )


def test_drive_to_offset_still_gives_up_on_a_persistent_failure() -> None:
    camera = _AlwaysFailingCamera()
    worker = _make_worker(camera)

    result = worker._drive_to_offset(10)

    # Must not reach the target, and must not spin through all 400 guard
    # iterations either -- it should bail out after the bounded retry budget.
    assert result == 0
    assert camera.calls <= 5, (
        f"expected to give up quickly after a few retries, made {camera.calls} focus_step calls"
    )
