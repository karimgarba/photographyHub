from desktop_ui.app import main


if __name__ == "__main__":
    raise SystemExit(main())